from mrjob.job import MRJob
from mrjob.step import MRStep
import re
import heapq

WORD_RE = re.compile(r"[\w']+")

class BigramCount2(MRJob):
    def mapper(self, _, line):
        words = WORD_RE.findall(line)
        for i in range(len(words)-1):  # words order
            bigrams=sorted([words[i],words[i+1]])
            yield ' '.join(bigrams),1

    def reducer(self, bigram, counts): # count bigram
        yield None,[sum(counts),bigram]
        
    def top10(self,_,values): # set the top 10 values
        for c,val in heapq.nlargest(10,values):
            yield c,val
            
    def steps(self):
        return [MRStep(mapper=self.mapper,reducer=self.reducer),
                MRStep(reducer=self.top10)]       


if __name__ == '__main__':
    BigramCount2.run()