from mrjob.job import MRJob
from mrjob.step import MRStep
import re
import heapq

WORD_RE = re.compile(r"[\w']+")

class wordcount(MRJob):
    def mapper(self, _, line):
        word = WORD_RE.findall(line)
        for i in range(len(word)):
            yield word[i],1

    def reducer(self, key, counts):
        yield None,[sum(counts),key]

    def top10(self,_,values): 
        for c,val in heapq.nlargest(10,values):
            yield c,val

    def steps(self):
        return [MRStep(mapper=self.mapper,reducer=self.reducer),
                MRStep(reducer=self.top10)]
    

if __name__ == '__main__':
    wordcount.run()
