from mrjob.job import MRJob
import nltk
from nltk.corpus import stopwords

class tokencount(MRJob):
    def mapper(self, _, line):
        """
        """
        english_stopwords=stopwords.words('english')
        tx=nltk.word_tokenize(unicode(line.lower(),'utf-8'))
        for i in tx: 
            if (len(i)>1) and (i not in english_stopwords) and i.isalnum():
                yield i,1

    def reducer(self, key, val):
        yield key,sum(val)
        

if __name__ == '__main__':
    tokencount.run()
