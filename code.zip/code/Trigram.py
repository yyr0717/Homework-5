from mrjob.job import MRJob
from mrjob.step import MRStep
import re
import heapq

WORD_RE = re.compile(r"[\w']+")

class trigramscount(MRJob):
    def mapper(self, _, line):
        word = WORD_RE.findall(line)
        for i in range(len(word)-2): 
            Trigrams=sorted([word[i],word[i+1],word[i+2]])
            yield ' '.join(Trigrams),1

    def reducer(self, trigrams, counts):
        yield None,[sum(counts),trigrams]
        
    def top10(self,_,values): 
        for c,val in heapq.nlargest(10,values):
            yield c,val
            
    def steps(self):
        return [MRStep(mapper=self.mapper,reducer=self.reducer),
                MRStep(reducer=self.top10)]       


if __name__ == '__main__':
    trigramscount.run()