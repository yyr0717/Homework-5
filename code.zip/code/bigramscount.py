from mrjob.job import MRJob
from mrjob.step import MRStep
import re
import heapq
from itertools import islice, izip
import itertools

WORD_RE = re.compile(r"[\w']+")

class BigramCount(MRJob):
    def mapper(self, _, line):
        words = WORD_RE.findall(line)
        for i in izip(words, islice(words, 1, None)):
            bigram=str(i[0]+" "+i[1])
            yield (bigram, 1)

    def reducer(self, bigram, counts):
        yield None,[sum(counts),bigram]
        
    def top10(self,_,values): 
        for c,val in heapq.nlargest(10,values):
            yield c,val
            
    def steps(self):
        return[MRStep(mapper=self.mapper,reducer=self.reducer),
           MRStep(reducer=self.top10)]       


if __name__ == '__main__':
    BigramCount.run()